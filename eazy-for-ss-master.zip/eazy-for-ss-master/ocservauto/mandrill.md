#Mandrill

请先注册mandrill帐号，然后获取api，绑定域名。将域名和有效api填写到脚本中。例如
```
API_KEY="123"
DOMAIN="123.com"
```

然后，将脚本和证书文件放到相同文件夹下，执行
```
bash mandrill.sh 'my.p12' 'my-email@abc.com'
```

#Mailgun

使用mailigun的请查阅https://blog.qmz.me/zai-vpsshang-da-jian-anyconnect-vpnfu-wu-qi/
