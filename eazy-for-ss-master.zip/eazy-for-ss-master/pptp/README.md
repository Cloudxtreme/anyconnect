##USAGE
```shell
wget https://raw.githubusercontent.com/fanyueciyuan/eazy-for-ss/master/pptp/pptpauto.sh --no-check-certificate
bash pptpauto.sh
```
##WARN
PPTP这个东西主要不是为了穿墙用的，但是可以给国内的vps(debian)开一个当跳板玩玩。
